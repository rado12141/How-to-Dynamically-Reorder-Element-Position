function displayItem(){
	var arr = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"];
	var html = "";
	for(var i=0; i<arr.length; i++){
		html += "<div width='200' height='200' style='border:1px solid #000; padding:30px; margin:15px; font-size:50px; float:left;'>"+arr[i]+"</div>";
	}
	html += "<br style='clear:both;'/>";
	
	document.getElementById('result').innerHTML = html;
}

function reOrder(){
	var arr = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"];
	var html = "";
	arrayRear(arr).forEach(function(item){
		html += "<div width='200' height='200' style='border:1px solid #000; padding:30px; margin:15px; font-size:50px; float:left;'>"+item+"</div>";
	})
	html += "<br style='clear:both;'/>";
	
	document.getElementById('result').innerHTML = html;
}

function arrayRear(arr) {
    for (var i = 0, rear = [], randomIndex = 0; i < arr.length; i++) {
        randomIndex = Math.floor(Math.random() *  arr.length);
        while (rear.indexOf(arr[randomIndex]) !== -1) {
            randomIndex = Math.floor(Math.random() *  arr.length);
        }
       rear.push(arr[randomIndex]);
    }
    
	return rear;
}

